<?php
    return [
        'dsn'=>'mysql:host=localhost;dbname=list_tasks;charset=utf8',
        'user'=>'admin',
        'password'=>'123',
    ];