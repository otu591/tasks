<?php
    return[

        'title'=>'Задачник',
        'pagination'=>3,

    
    ];
