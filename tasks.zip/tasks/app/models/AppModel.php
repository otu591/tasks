<?php
    
    
    namespace app\models;
    
    
    use tasks\base\Model;

    class AppModel extends Model
    {
        
    }